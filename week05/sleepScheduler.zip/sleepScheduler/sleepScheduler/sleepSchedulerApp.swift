//
//  sleepSchedulerApp.swift
//  sleepScheduler
//
//  Created by Vlera Mehani on 25/10/2024.
//

import SwiftUI

@main
struct sleepSchedulerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
