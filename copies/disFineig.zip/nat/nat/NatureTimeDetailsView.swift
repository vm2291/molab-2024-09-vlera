import SwiftUI

struct NatureTimeDetailsView: View {
    @AppStorage("NatureTimeLogs") private var logsData: String = "{}" // Store logs as a JSON string
    @State private var logs: [String: [LogEntry]] = [:]
    @State private var selectedDate: String = NatureTimeTrackerView.formatDate(Date())

    var body: some View {
        VStack(spacing: 20) {
            Text("Nature Time Details")
                .font(.largeTitle)
                .padding()

            // Display the selected date
            Text("Date: \(selectedDate)")
                .font(.headline)

            // Show logs for the selected date
            List {
                ForEach(logs[selectedDate, default: []]) { log in
                    HStack {
                        Text("Start: \(formatTime(log.startTime))")
                        Spacer()
                        Text("Duration: \(formatDuration(log.duration))")
                    }
                }
            }

            // Swipe controls to navigate dates
            HStack {
                Button(action: previousDate) {
                    Image(systemName: "arrow.left.circle")
                        .font(.largeTitle)
                }
                Spacer()
                Button(action: nextDate) {
                    Image(systemName: "arrow.right.circle")
                        .font(.largeTitle)
                }
            }
            .padding()
        }
        .padding()
        .onAppear {
            loadLogs()
        }
    }

    func previousDate() {
        if let newDate = Calendar.current.date(byAdding: .day, value: -1, to: parseDate(selectedDate)) {
            selectedDate = NatureTimeTrackerView.formatDate(newDate)
        }
    }

    func nextDate() {
        if let newDate = Calendar.current.date(byAdding: .day, value: 1, to: parseDate(selectedDate)) {
            selectedDate = NatureTimeTrackerView.formatDate(newDate)
        }
    }

    func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        return String(format: "%02dh %02dm", hours, minutes)
    }

    func parseDate(_ dateString: String) -> Date {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMM d, yyyy"
        return formatter.date(from: dateString) ?? Date()
    }

    func loadLogs() {
        if let data = logsData.data(using: .utf8),
           let decodedLogs = try? JSONDecoder().decode([String: [LogEntry]].self, from: data) {
            logs = decodedLogs
        }
    }
}

