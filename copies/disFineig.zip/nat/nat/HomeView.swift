import SwiftUI

struct HomeView: View {
    @AppStorage("NatureTimeLogs") private var logsData: String = "{}" // Store logs as a JSON string
    @State private var logs: [String: [LogEntry]] = [:]

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Nature Along Dashboard")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                // Show summary of today's activity
                VStack {
                    Text("Today:")
                        .font(.headline)
                    Text(totalTimeToday())
                        .font(.title2)
                        .fontWeight(.bold)
                }
                .padding()
                .background(Color.blue.opacity(0.2))
                .cornerRadius(15)

                // Navigate to detailed view
                NavigationLink(destination: NatureTimeDetailsView()) {
                    Text("View Details")
                        .font(.title2)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }

                Spacer()
            }
            .padding()
            .navigationTitle("Home")
            .onAppear {
                loadLogs()
            }
        }
    }

    func totalTimeToday() -> String {
        let today = NatureTimeTrackerView.formatDate(Date())
        let dayLogs = logs[today, default: []]
        let totalTime = dayLogs.reduce(0) { $0 + $1.duration }
        let hours = Int(totalTime) / 3600
        let minutes = (Int(totalTime) % 3600) / 60
        return String(format: "%02dh %02dm", hours, minutes)
    }

    func loadLogs() {
        if let data = logsData.data(using: .utf8),
           let decodedLogs = try? JSONDecoder().decode([String: [LogEntry]].self, from: data) {
            logs = decodedLogs
        }
    }
}

