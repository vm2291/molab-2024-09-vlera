//
//  HomeView.swift
//  nat
//
//  Created by Vlera Mehani on 10/12/2024.
//


import SwiftUI

struct HomeView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Nature Along Dashboard")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                // Weekly Time Spent in Nature
                Text("Your Time in Nature This Week:")
                    .font(.headline)
                Rectangle()
                    .fill(Color.green.opacity(0.3))
                    .frame(height: 150)
                    .cornerRadius(15)
                    .padding()

                // Example Summary Stats
                HStack {
                    VStack {
                        Text("Total Time")
                            .font(.subheadline)
                        Text("5h 30m")
                            .font(.title2)
                            .fontWeight(.bold)
                    }
                    .padding()
                    VStack {
                        Text("Sessions")
                            .font(.subheadline)
                        Text("3")
                            .font(.title2)
                            .fontWeight(.bold)
                    }
                    .padding()
                }
                .frame(maxWidth: .infinity)
                .background(Color.blue.opacity(0.2))
                .cornerRadius(15)
                .padding()

                Spacer()
            }
            .navigationTitle("Home")
        }
    }
}
