//
//  MainView.swift
//  nat
//
//  Created by Vlera Mehani on 10/12/2024.
//


import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            NatureAudiosView()
                .tabItem {
                    Image(systemName: "music.note")
                    Text("Nature Sounds")
                }
            NatureTimeTrackerView()
                .tabItem {
                    Image(systemName: "timer")
                    Text("Time Tracker")
                }
            NatureJournalView()
                .tabItem {
                    Image(systemName: "book")
                    Text("Journal")
                }
        }
        .accentColor(.green)
    }
}
