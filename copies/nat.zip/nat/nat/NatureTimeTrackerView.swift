//
//  NatureTimeTrackerView.swift
//  nat
//
//  Created by Vlera Mehani on 10/12/2024.
//


import SwiftUI

struct NatureTimeTrackerView: View {
    @State private var timeSpent: TimeInterval = 0
    @State private var timer: Timer?
    @State private var isTracking = false

    var body: some View {
        VStack(spacing: 20) {
            Text("Nature Time Tracker")
                .font(.largeTitle)
                .padding()

            Text(formatTime(timeSpent))
                .font(.system(size: 50))
                .padding()

            if isTracking {
                Button(action: stopTracking) {
                    Text("Stop Tracking")
                        .font(.title2)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            } else {
                Button(action: startTracking) {
                    Text("Start Tracking")
                        .font(.title2)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
        }
        .padding()
    }

    func startTracking() {
        isTracking = true
        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            timeSpent += 1
        }
    }

    func stopTracking() {
        isTracking = false
        timer?.invalidate()
        timer = nil
    }

    func formatTime(_ time: TimeInterval) -> String {
        let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
}
