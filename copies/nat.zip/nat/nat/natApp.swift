//
//  natApp.swift
//  nat
//
//  Created by Vlera Mehani
//

import SwiftUI

@main
struct natApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
