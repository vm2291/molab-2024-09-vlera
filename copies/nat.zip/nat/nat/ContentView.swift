/*import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Nature Along")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .padding()

                NavigationLink(destination: NatureTimeTrackerView()) {
                    HomeButton(title: "Track Nature Time")
                }

                NavigationLink(destination: NatureJournalView()) {
                    HomeButton(title: "Nature Journal")
                }

                NavigationLink(destination: NatureAudiosView()) {
                    HomeButton(title: "Nature Sounds")
                }
            }
            .padding()
            .navigationTitle("Home")
        }
    }
}

struct HomeButton: View {
    let title: String

    var body: some View {
        Text(title)
            .font(.headline)
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color.green.opacity(0.3))
            .cornerRadius(15)
            .shadow(radius: 5)
    }
}

*/
