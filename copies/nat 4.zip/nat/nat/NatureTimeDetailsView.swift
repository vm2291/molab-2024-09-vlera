import SwiftUI

struct NatureTimeDetailsView: View {
    let date: Date
    @AppStorage("NatureTimeLogs") private var logsData: Data = Data()
    @State private var logs: [LogEntry] = []

    var body: some View {
        VStack {
            Text("Nature Time Details")
                .font(.largeTitle)
                .padding()

            Text("Date: \(formatDate(date))")
                .font(.headline)
                .padding(.bottom)

            if logs.isEmpty {
                Text("No logs for this day.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
            } else {
                List(logs) { log in
                    HStack {
                        Text("Start: \(formatTime(log.startTime))")
                        Spacer()
                        Text("Duration: \(formatDuration(log.duration))")
                    }
                }
            }

            Spacer()
        }
        .onAppear(perform: fetchLogsForDate)
    }

    func fetchLogsForDate() {
        let allLogs = fetchLogs()
        let dateKey = formatDate(date)
        logs = allLogs[dateKey] ?? []
    }

    func fetchLogs() -> [String: [LogEntry]] {
        if let decoded = try? JSONDecoder().decode([String: [LogEntry]].self, from: logsData) {
            return decoded
        }
        return [:]
    }

    func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }

    func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        let seconds = Int(duration) % 60
        return String(format: "%02dh %02dm %02ds", hours, minutes, seconds)
    }
}

