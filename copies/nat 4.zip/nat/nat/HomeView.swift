import SwiftUI

struct HomeView: View {
    @AppStorage("NatureTimeLogs") private var logsData: Data = Data()
    @State private var totalTimeToday: TimeInterval = 0

    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Text("Nature Along Dashboard")
                    .font(.largeTitle)
                    .padding()

                NavigationLink(destination: NatureTimeDetailsView(date: Date())) {
                    VStack(alignment: .leading) {
                        Text("Time in Nature")
                            .font(.headline)
                        Text(formatTime(totalTimeToday))
                            .font(.title2)
                    }
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green.opacity(0.2))
                    .cornerRadius(15)
                    .shadow(radius: 5)
                }
                Spacer()
            }
            .padding()
            .navigationTitle("Home")
            .onAppear(perform: fetchTotalTimeToday)
        }
    }

    func fetchTotalTimeToday() {
        let logs = fetchLogs()
        let todayKey = formatDate(Date())
        totalTimeToday = logs[todayKey]?.reduce(0) { $0 + $1.duration } ?? 0
    }

    func fetchLogs() -> [String: [LogEntry]] {
        if let decoded = try? JSONDecoder().decode([String: [LogEntry]].self, from: logsData) {
            return decoded
        }
        return [:]
    }

    func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: date)
    }

    func formatTime(_ time: TimeInterval) -> String {
        let hours = Int(time) / 3600
        let minutes = (Int(time) % 3600) / 60
        let seconds = Int(time) % 60
        return String(format: "%02dh %02dm %02ds", hours, minutes, seconds)
    }
}

