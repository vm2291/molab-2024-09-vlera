import Foundation

struct LogEntry: Codable, Identifiable {
    let id: UUID
    let startTime: Date
    let duration: TimeInterval
}
